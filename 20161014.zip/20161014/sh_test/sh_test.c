#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "sm2.h"
#include "sm3.h"
#include "sm4.h"


#define TAG    "sh_test"

typedef unsigned char uchar;


void smsw_test()
{
	int ret = -99;

	ST_SM2_KEY *sm2Key = (ST_SM2_KEY *)malloc(sizeof(ST_SM2_KEY));
	memset(sm2Key, 0, sizeof(ST_SM2_KEY));

	ret = SM2GenKeyPair_sw(sm2Key);
	printf("SM2GenKeyPair_sw ret = %d\n", ret);

	int i;
	printf("\npvKey: \n");
	for(i = 0; i < sizeof(sm2Key->privkey) / 16; i++) {
		printf("%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x\n", 
			sm2Key->privkey[i*16], sm2Key->privkey[i*16+1], sm2Key->privkey[i*16+2], sm2Key->privkey[i*16+3],
			sm2Key->privkey[i*16+4], sm2Key->privkey[i*16+5], sm2Key->privkey[i*16+6], sm2Key->privkey[i*16+7],
			sm2Key->privkey[i*16+8], sm2Key->privkey[i*16+9], sm2Key->privkey[i*16+10], sm2Key->privkey[i*16+11],
			sm2Key->privkey[i*16+12], sm2Key->privkey[i*16+13], sm2Key->privkey[i*16+14], sm2Key->privkey[i*16+15]
		);
	}
	printf("\n");

	printf("pbKey: \n");
	for(i = 0; i < sizeof(sm2Key->pubkey) / 16; i++) {
		printf("%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x\n", 
			sm2Key->pubkey[i*16], sm2Key->pubkey[i*16+1], sm2Key->pubkey[i*16+2], sm2Key->pubkey[i*16+3],
			sm2Key->pubkey[i*16+4], sm2Key->pubkey[i*16+5], sm2Key->pubkey[i*16+6], sm2Key->pubkey[i*16+7],
			sm2Key->pubkey[i*16+8], sm2Key->pubkey[i*16+9], sm2Key->pubkey[i*16+10], sm2Key->pubkey[i*16+11],
			sm2Key->pubkey[i*16+12], sm2Key->pubkey[i*16+13], sm2Key->pubkey[i*16+14], sm2Key->pubkey[i*16+15]
		);
	}
	printf("\n");

    printf("--------------------------\n");
    uchar datain[32] = {
        0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 
        0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18,
        0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28,
        0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38
    };
    uchar dataout[1024];
    memset(dataout, 0, sizeof(dataout));

    int dataoutlen = 0;

    ret = SM2Recover_sw(sm2Key, datain, sizeof(datain), dataout, &dataoutlen, 1);
    printf("SM2Recover_sw ret=%d, dataoutlen=%d\n", ret, dataoutlen);

    printf("dataoutlen: \n");
    for(i = 0; i < dataoutlen; i++) {
		printf("%x\n", dataout[i]);
    }


	free(sm2Key);

}

void main()
{
	smsw_test();

}



