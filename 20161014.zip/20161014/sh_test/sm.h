#ifndef _SM_ALL_H
#define _SM_ALL_H

#define SM_RET_OK					 0
#define SM_RET_INVALID_PARAM	    -1
#define SM_RET_ERROR				-2
#define SM_RET_TIMEOUT				-3

//#define _debug_sm_
#include "sm2.h"
#include "sm3.h"
#include "sm4.h"

#endif
