#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "common.h"

void init_test()
{
    char dir[1024];
    char apk_path[1024];
    char cert_path[1024];
    int ret = 0;

    const char *apk_name = "demo_sgn.apk";
    const char *cert_name = "test.crt";

    memset(apk_path, 0, 1024);
    memset(cert_path, 0, 1024);
    getcwd(dir, 1024);
    sprintf(apk_path, "%s/%s", dir, apk_name);
    sprintf(cert_path, "%s/%s", dir, cert_name);

    ret = EA_ucAuthenticateAPKUms(apk_path, cert_path);
    printf("ums_test ret = %d\n", ret);
}

int my_ucAuthenticateAPKUms(char *apk_path, char *cert_path)
{
    char *vApkName = apk_path;
    char *vCertName = cert_path;
    FILE *vApkFILE;
    FILE *vApkFILE_tmp;
    int vApkFileSize;

    _BYTE *vPucData;

    size_t r_len;

    void *vApkFileBuf;

    printf("pcSourceFilePath = %s, pcSignFilePath = %s \n", vApkName, vCertName);
    vApkFILE = fopen(vApkName, "rb");
    vApkFILE_tmp = vApkFILE;

    fseek(vApkFILE_tmp, 0, 2);
    vApkFileSize = ftell(vApkFILE_tmp);
    if (vApkFILE_tmp < 0x11) {
        printf("File too small.\n");
        vApkFileBuf = NULL;
        fclose(vApkFILE_tmp);
        return 0;
    }

    vApkFileBuf =  malloc(vApkFileSize);
    if (vApkFileBuf == NULL) {
        printf("vApkFileBuf: Malloc Err.\n");
        fclose(vApkFILE_tmp);
        return 0;
    }

    fseek(vApkFILE_tmp, 0, 0);
    r_len = fread(vApkFileBuf, 1, vApkFileSize, vApkFILE_tmp);
    if (r_len != vApkFileSize) {
        printf("fail to read data from file.\n");
        fclose(vApkFILE_tmp);
        return 0;
    }

    fclose(vApkFILE_tmp);

    char v_cmd[512];
    if (access("/tmp/libfamtmp/", 0)) {
        memset(v_cmd, 0, 512);
        sprintf(v_cmd, "mkdir %s", "/tmp/libfamtmp/");
        system(v_cmd);
        memset(v_cmd, 0, 512);
        sprintf(v_cmd, "chmod 777 %s", "/tmp/libfamtmp/");
        system(v_cmd);
    }

    //TODO:
    vPucData = (_BYTE *)EA_pucMemFindData(1, vApkFileBuf, vApkFileSize - 18, &unk_7B8C, 4);
    if (vPucData == NULL) {
        printf("fail to find dir end label 0x06054b50.\n");
    }

    return 0;

}


void test_my()
{
    char dir[1024];
    char apk_path[1024];
    char cert_path[1024];
    int ret = 0;

    const char *apk_name = "demo_sgn.apk";
    const char *cert_name = "test.crt";

    memset(apk_path, 0, 1024);
    memset(cert_path, 0, 1024);
    getcwd(dir, 1024);
    sprintf(apk_path, "%s/%s", dir, apk_name);
    sprintf(cert_path, "%s/%s", dir, cert_name);

    ret = my_ucAuthenticateAPKUms(apk_path, cert_path);
    printf("ums_test ret = %d\n", ret);
}

void main()
{
    // init_test();
    test_my();
}