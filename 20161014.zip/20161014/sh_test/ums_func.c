#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "common.h"


int EA_pucMemFindData(int a1, void *a2, int a3, void *a4, size_t a5)
{
  int v5;
  char *v6;
  void *v7;
  int v8;
  char *v9;
  int v10;
  int v11;

  v5 = 1 - (_DWORD)a2;
  v6 = (char *)a2;
  v7 = a4;
  if ( (unsigned int)a2 > 1 )
    v5 = 0;
  if ( !a3 )
    v5 |= 1u;
  if ( v5 )
    goto LABEL_20;
  v8 = a4 == 0;
  if ( !a5 )
    v8 |= 1u;
  if ( !v8 )
  {
    if ( a5 > a3 )
      return 0;
    v9 = (char *)a2 + a3 - a5;
    if ( a1 == 1 )
    {
      while ( 1 )
      {
        v5 = (int)v9;
        if ( v9 < v6 )
          break;
        v10 = (unsigned __int8) * v9--;
        if ( v10 == *(_BYTE *)v7 && !memcmp((const void *)v5, v7, a5) )
          return v5;
      }
    }
    else
    {
      while ( 1 )
      {
        v5 = (int)v6;
        if ( v6 > v9 )
          break;
        v11 = (unsigned __int8) * v6++;
        if ( v11 == *(_BYTE *)v7 && !memcmp((const void *)v5, v7, a5) )
          return v5;
      }
    }
LABEL_20:
    v5 = 0;
  }
  return v5;
}

int EA_uiLEndHexTo4ByteUint(int a1)
{
  return (*(_BYTE *)(a1 + 2) << 16) + (*(_BYTE *)(a1 + 1) << 8) + *(_BYTE *)a1 + (*(_BYTE *)(a1 + 3) << 24);
}

unsigned int EA_v4ByteUintToLEndHex(unsigned int a1, int a2)
{
  unsigned int v2;
  unsigned int v3;
  unsigned int result;

  v2 = a1 >> 8;
  v3 = a1 >> 16;
  *(_BYTE *)a2 = a1;
  result = a1 >> 24;
  *(_BYTE *)(a2 + 1) = v2;
  *(_BYTE *)(a2 + 2) = v3;
  *(_BYTE *)(a2 + 3) = result;
  return result;
}

unsigned int EA_v2ByteUshortToLEndHex(unsigned int a1, int a2)
{
  unsigned int result;

  *(_BYTE *)a2 = a1;
  result = a1 >> 8;
  *(_BYTE *)(a2 + 1) = result;
  return result;
}

unsigned int EA_v4ByteUintToLEndHex(unsigned int a1, int a2)
{
  unsigned int v2;
  unsigned int v3;
  unsigned int result;

  v2 = a1 >> 8;
  v3 = a1 >> 16;
  *(_BYTE *)a2 = a1;
  result = a1 >> 24;
  *(_BYTE *)(a2 + 1) = v2;
  *(_BYTE *)(a2 + 2) = v3;
  *(_BYTE *)(a2 + 3) = result;
  return result;
}

const char * EA_pcMemstr(unsigned int a1, int a2, const char *a3)
{
  int v3;
  const char *v4;
  int v5;
  const char *v6;
  const char *v7;
  int v8;
  size_t v9;
  int v10;
  int v11;

  v3 = 1 - a1;
  v4 = (const char *)a1;
  v5 = a2;
  if ( a1 > 1 )
    v3 = 0;
  if ( !a2 )
    v3 |= 1u;
  v6 = a3;
  if ( v3 )
    return 0;
  v7 = a3;
  if ( a3 )
  {
    v8 = *a3;
    v7 = (const char *)*a3;
    if ( *a3 )
    {
      v9 = strlen(a3);
      v10 = v5 + 1 - v9;
      while ( 1 )
      {
        v7 = v4;
        if ( v3 == v10 )
          break;
        v11 = *v4++;
        if ( v11 == v8 && !memcmp(v7, v6, v9) )
          return v7;
        ++v3;
      }
      return 0;
    }
  }
  return v7;
}

signed int EI_fam_ucGetSeqInfo(_BYTE *a1, int *a2, char *a3, int a4)
{
  int v4; // r3@1
  char v5; // r4@2
  signed int result; // r0@3
  signed int v7; // r5@4
  int v8; // r6@4
  char v9; // r4@6
  int v10; // [sp+0h] [bp-18h]@1

  v10 = a4;
  *a2 = 0;
  *a3 = 0;
  v4 = *a1;
  if ( v4 & 0x80 )
  {
    v5 = v4 & 0x7F;
    if ( (unsigned __int8)((v4 & 0x7F) - 1) > 1u )
    {
      printf(
        "[File] : %s; [Line] : %d; [Func] : %s; err.",
        "epay/security/fam/jni/common/signfilefunApi.c",
        66,
        "EI_fam_ucGetSeqInfo",
        v10);
      return 1;
    }
    v4 = 0;
    v7 = 1;
    LOBYTE(v8) = v5;
    do
    {
      v8 = (unsigned __int8)(v8 - 1);
      v4 = a1[v7] + (v4 << 8);
      v7 = (unsigned __int8)(v7 + 1);
    }
    while ( v8 );
    v9 = v5 + 1;
  }
  else
  {
    v9 = 1;
  }
  *a2 = v4;
  result = 0;
  *a3 = v9;
  return result;
}

signed int EA_ucGetFileHeadInfo(_BYTE *a1, int a2, int a3)
{
  int v3;
  _BYTE *v4;
  int v5;
  int v6;
  signed int v7;
  const char *v8;
  const char *v9;
  const char *v10;
  int v11;
  int v12;
  int v13;
  int v14;
  signed int v15;
  const char *v16;
  const char *v17;
  const char *v18;
  unsigned int v19;
  int v20;
  int v21;
  int v22;
  unsigned int v23;
  int v24;
  int v25;
  int v26;
  int v27;
  int v28;
  char v29;
  int v30;
  int v31;
  int v32;
  int v33;
  unsigned int v34;
  int v35;
  int v36;
  int v37;
  int v38;
  int v39;
  int v40;
  int v41;
  int v42;
  int v43;
  int v44;
  _BYTE *v45;
  int v46;
  _BYTE *v47;
  unsigned int v48;
  int v49;
  int v50;
  int v51;
  int v52;
  unsigned int v54;
  int v55;
  int v56;
  int v57;

  v3 = 1 - (_DWORD)a1;
  v54 = (unsigned int)a1;
  v57 = a2;
  if ( (unsigned int)a1 > 1 )
    v3 = 0;
  if ( !a2 )
    v3 |= 1u;
  v4 = a1;
  v5 = a2;
  v6 = a3;
  if ( v3 || !a3 )
    return 2;
  if ( *a1 != 48 )
  {
    v7 = 125;
    v8 = "[File] : %s; [Line] : %d; [Func] : %s; err.";
    v9 = "epay/security/fam/jni/common/signfilefunApi.c";
    v10 = "EA_ucGetFileHeadInfo";
LABEL_11:
    printf(v8, v9, v7, v10, v55);
    return 1;
  }
  v11 = (int)(a1 + 1);
  if ( EI_fam_ucGetSeqInfo(a1 + 1, &v57, (char *)&v54 + 3) )
  {
    v7 = 131;
    v8 = "[File] : %s; [Line] : %d; [Func] : %s; err.";
    v9 = "epay/security/fam/jni/common/signfilefunApi.c";
    v10 = "EA_ucGetFileHeadInfo";
    goto LABEL_11;
  }
  v13 = v57 + 1 + BYTE3(v54);
  if ( v13 != v5 )
  {
    v7 = 136;
    v8 = "[File] : %s; [Line] : %d; [Func] : %s; err.";
    v9 = "epay/security/fam/jni/common/signfilefunApi.c";
    v10 = "EA_ucGetFileHeadInfo";
    goto LABEL_11;
  }
  if ( *(_BYTE *)(v11 + BYTE3(v54)) != 2 )
  {
    v7 = 146;
    v8 = "[File] : %s; [Line] : %d; [Func] : %s; err.";
    v9 = "epay/security/fam/jni/common/signfilefunApi.c";
    v10 = "EA_ucGetFileHeadInfo";
    goto LABEL_11;
  }
  v14 = v11 + BYTE3(v54) + 1;
  v12 = EI_fam_ucGetSeqInfo(v14, &v57, (char *)&v54 + 3);
  if ( v12 == 1 )
  {
    v15 = 152;
    v16 = "[File] : %s; [Line] : %d; [Func] : %s; err.";
    v17 = "epay/security/fam/jni/common/signfilefunApi.c";
    v18 = "EA_ucGetFileHeadInfo";
LABEL_58:
    printf(v16, v17, v15, v18, v56);
    return v12;
  }
  v19 = (unsigned int)&v4[v13];
  v20 = v14 + BYTE3(v54);
  v21 = *(_BYTE *)(v14 + BYTE3(v54));
  *(_DWORD *)(v6 + 4) = v14 + BYTE3(v54) - (_DWORD)v4;
  *(_DWORD *)(v6 + 8) = v21;
  v22 = v57;
  v23 = v20 + v57;
  *(_DWORD *)v6 = v57;
  if ( v23 >= v19 )
  {
    v7 = 168;
    v8 = "[File] : %s; [Line] : %d; [Func] : %s; err.";
    v9 = "epay/security/fam/jni/common/signfilefunApi.c";
    v10 = "EA_ucGetFileHeadInfo";
    goto LABEL_11;
  }
  if ( *(_BYTE *)(v20 + v22) != 2 )
  {
    v7 = 176;
    v8 = "[File] : %s; [Line] : %d; [Func] : %s; err.";
    v9 = "epay/security/fam/jni/common/signfilefunApi.c";
    v10 = "EA_ucGetFileHeadInfo";
    goto LABEL_11;
  }
  v24 = v23 + 1;
  if ( EI_fam_ucGetSeqInfo(v24, &v57, (char *)&v54 + 3) == 1 )
  {
    v7 = 182;
    v8 = "[File] : %s; [Line] : %d; [Func] : %s; err.";
    v9 = "epay/security/fam/jni/common/signfilefunApi.c";
    v10 = "EA_ucGetFileHeadInfo";
    goto LABEL_11;
  }
  v25 = v24 + BYTE3(v54);
  v26 = *(_DWORD *)(v24 + BYTE3(v54));
  *(_DWORD *)(v6 + 16) = v24 + BYTE3(v54) - (_DWORD)v4;
  *(_DWORD *)(v6 + 20) = v26;
  v27 = v57;
  v28 = v25 + v57;
  v29 = v25 + v57 >= v19;
  *(_DWORD *)(v6 + 12) = v57;
  if ( v29 )
  {
    v7 = 197;
    v8 = "[File] : %s; [Line] : %d; [Func] : %s; err.";
    v9 = "epay/security/fam/jni/common/signfilefunApi.c";
    v10 = "EA_ucGetFileHeadInfo";
    goto LABEL_11;
  }
  if ( *(_BYTE *)(v25 + v27) != 2 )
  {
    v7 = 205;
    v8 = "[File] : %s; [Line] : %d; [Func] : %s; err.";
    v9 = "epay/security/fam/jni/common/signfilefunApi.c";
    v10 = "EA_ucGetFileHeadInfo";
    goto LABEL_11;
  }
  v30 = v28 + 1;
  v12 = EI_fam_ucGetSeqInfo(v30, &v57, (char *)&v54 + 3);
  if ( v12 == 1 )
  {
    v15 = 211;
    v16 = "[File] : %s; [Line] : %d; [Func] : %s; err.";
    v17 = "epay/security/fam/jni/common/signfilefunApi.c";
    v18 = "EA_ucGetFileHeadInfo";
    goto LABEL_58;
  }
  v31 = v57;
  v32 = v30 + BYTE3(v54);
  v33 = *(_DWORD *)(v30 + BYTE3(v54));
  v34 = v30 + BYTE3(v54) + v57;
  *(_DWORD *)(v6 + 24) = v57;
  *(_DWORD *)(v6 + 32) = v33;
  *(_DWORD *)(v6 + 28) = v32 - (_DWORD)v4;
  if ( v34 >= v19 )
  {
    v7 = 226;
    v8 = "[File] : %s; [Line] : %d; [Func] : %s; err.";
    v9 = "epay/security/fam/jni/common/signfilefunApi.c";
    v10 = "EA_ucGetFileHeadInfo";
    goto LABEL_11;
  }
  if ( *(_BYTE *)(v32 + v31) != 2 )
  {
    v7 = 234;
    v8 = "[File] : %s; [Line] : %d; [Func] : %s; err.";
    v9 = "epay/security/fam/jni/common/signfilefunApi.c";
    v10 = "EA_ucGetFileHeadInfo";
    goto LABEL_11;
  }
  v35 = v34 + 1;
  v12 = EI_fam_ucGetSeqInfo(v35, &v57, (char *)&v54 + 3);
  if ( v12 == 1 )
  {
    v15 = 240;
    v16 = "[File] : %s; [Line] : %d; [Func] : %s; err.";
    v17 = "epay/security/fam/jni/common/signfilefunApi.c";
    v18 = "EA_ucGetFileHeadInfo";
    goto LABEL_58;
  }
  v36 = v35 + BYTE3(v54);
  v37 = *(_DWORD *)(v35 + BYTE3(v54));
  *(_DWORD *)(v6 + 40) = v35 + BYTE3(v54) - (_DWORD)v4;
  v38 = v57;
  *(_DWORD *)(v6 + 44) = v37;
  *(_DWORD *)(v6 + 36) = v38;
  if ( v36 + v38 >= v19 )
  {
    v7 = 255;
    v8 = "[File] : %s; [Line] : %d; [Func] : %s; err.";
    v9 = "epay/security/fam/jni/common/signfilefunApi.c";
    v10 = "EA_ucGetFileHeadInfo";
    goto LABEL_11;
  }
  if ( *(_BYTE *)(v36 + v38) != 2 )
  {
    v7 = 263;
    v8 = "[File] : %s; [Line] : %d; [Func] : %s; err.";
    v9 = "epay/security/fam/jni/common/signfilefunApi.c";
    v10 = "EA_ucGetFileHeadInfo";
    goto LABEL_11;
  }
  v39 = v36 + v38 + 1;
  v12 = EI_fam_ucGetSeqInfo(v39, &v57, (char *)&v54 + 3);
  if ( v12 == 1 )
    return v12;
  v40 = v57;
  v41 = v39 + BYTE3(v54);
  v42 = v41 + v57;
  v29 = v41 + v57 >= v19;
  *(_DWORD *)(v6 + 52) = v41 - (_DWORD)v4;
  *(_DWORD *)(v6 + 48) = v40;
  if ( v29 )
  {
    v7 = 280;
    v8 = "[File] : %s; [Line] : %d; [Func] : %s; err.";
    v9 = "epay/security/fam/jni/common/signfilefunApi.c";
    v10 = "EA_ucGetFileHeadInfo";
    goto LABEL_11;
  }
  if ( *(_BYTE *)(v41 + v40) != 163 )
  {
    v7 = 288;
    v8 = "[File] : %s; [Line] : %d; [Func] : %s; err.";
    v9 = "epay/security/fam/jni/common/signfilefunApi.c";
    v10 = "EA_ucGetFileHeadInfo";
    goto LABEL_11;
  }
  v43 = v42 + 1;
  v12 = EI_fam_ucGetSeqInfo(v42 + 1, &v57, (char *)&v54 + 3);
  if ( v12 == 1 )
  {
    v15 = 294;
    v16 = "[File] : %s; [Line] : %d; [Func] : %s; err.";
    v17 = "epay/security/fam/jni/common/signfilefunApi.c";
    v18 = "EA_ucGetFileHeadInfo";
    goto LABEL_58;
  }
  v44 = v57;
  v45 = (_BYTE *)(v43 + BYTE3(v54));
  *(_DWORD *)(v6 + 60) = v43 + BYTE3(v54) - (_DWORD)v4;
  *(_DWORD *)(v6 + 56) = v44;
  if ( *v45 != 48 )
  {
    v7 = 306;
    v8 = "[File] : %s; [Line] : %d; [Func] : %s; err.";
    v9 = "epay/security/fam/jni/common/signfilefunApi.c";
    v10 = "EA_ucGetFileHeadInfo";
    goto LABEL_11;
  }
  v46 = (int)(v45 + 1);
  v12 = EI_fam_ucGetSeqInfo(v46, &v57, (char *)&v54 + 3);
  if ( v12 == 1 )
  {
    v15 = 312;
    v16 = "[File] : %s; [Line] : %d; [Func] : %s; err.";
    v17 = "epay/security/fam/jni/common/signfilefunApi.c";
    v18 = "EA_ucGetFileHeadInfo";
    goto LABEL_58;
  }
  v47 = (_BYTE *)(v46 + BYTE3(v54));
  v48 = (unsigned int)&v47[v57];
  while ( (unsigned int)v47 < v48 )
  {
    if ( *v47 != 48 )
    {
      v7 = 326;
      v8 = "[File] : %s; [Line] : %d; [Func] : %s; err. \n";
      v9 = "epay/security/fam/jni/common/signfilefunApi.c";
      v10 = "EA_ucGetFileHeadInfo";
      goto LABEL_11;
    }
    v49 = (int)(v47 + 1);
    v12 = EI_fam_ucGetSeqInfo(v49, &v57, (char *)&v54 + 3);
    if ( v12 == 1 )
    {
      v15 = 332;
      v16 = "[File] : %s; [Line] : %d; [Func] : %s; err. \n";
      v17 = "epay/security/fam/jni/common/signfilefunApi.c";
      v18 = "EA_ucGetFileHeadInfo";
      goto LABEL_58;
    }
    v50 = v49 + BYTE3(v54);
    if ( !memcmp((const void *)(v50 + 2), "ACQUIRER-SGN-INFO", 0x11u) )
    {
      v51 = v57;
      *(_DWORD *)(v6 + 68) = v50 - (_DWORD)v4;
      *(_DWORD *)(v6 + 64) = v51;
    }
    else if ( !memcmp((const void *)(v50 + 2), "VENDOR-SGN-INFO", 0xFu) )
    {
      v52 = v57;
      *(_DWORD *)(v6 + 76) = v50 - (_DWORD)v4;
      *(_DWORD *)(v6 + 72) = v52;
    }
    v47 = (_BYTE *)(v50 + v57);
  }
  return 0;
}

signed int EA_fam_ucGetAcqrSignInfo(unsigned int a1, int a2, int a3, int a4)
{
  int v4;
  int v5;
  _BYTE *v6;
  int v7;
  int v8;
  bool v9;
  int v10;
  signed int v11;
  const char *v12;
  const char *v13;
  const char *v14;
  int v15;
  int v16;
  int v17;
  signed int v18;
  const char *v19;
  const char *v20;
  const char *v21;
  int v22;
  _BYTE *v23;
  int v24;
  int v25;
  int v26;
  unsigned int v27;
  int v28;
  int v29;
  signed int v30;
  const char *v31;
  const char *v32; // r1@31
  const char *v33; // r3@31
  const void *v34; // r9@32
  int v35; // r3@32
  int v36; // r9@36
  char *v37; // r9@39
  int v38; // r2@40
  int v39; // r3@40
  int v40; // r4@45
  const void *v41; // r4@47
  int v42; // r9@51
  const void *v43; // r9@54
  int v44; // r4@58
  int v45; // r2@60
  int v46; // r4@62
  int v47; // r4@64
  int v48; // r3@64
  int v49; // r4@68
  int v50; // r3@70
  int v51; // r4@70
  int v52; // r7@74
  int v53; // r1@76
  int v54; // r7@76
  int v55; // r2@76
  unsigned int v57; // [sp+0h] [bp-28h]@1
  int v58; // [sp+0h] [bp-28h]@9
  int v59; // [sp+0h] [bp-28h]@38
  int v60; // [sp+0h] [bp-28h]@53
  int v61; // [sp+0h] [bp-28h]@79
  int v62; // [sp+4h] [bp-24h]@1

  v57 = a1;
  v62 = a2;
  v4 = a4;
  v5 = 1 - a1;
  v6 = (_BYTE *)a1;
  v7 = a2;
  v8 = a3;
  if ( a1 > 1 )
    v5 = 0;
  if ( !a2 )
    v5 |= 1u;
  if ( !v5 )
  {
    v9 = a3 == 0;
    if ( !v4 )
      v9 = 1;
    if ( !v9 )
    {
      if ( *v6 != 48 )
      {
        v11 = 403;
        v12 = "[File] : %s; [Line] : %d; [Func] : %s; error.";
        v13 = "epay/security/fam/jni/common/signfilefunApi.c";
        v14 = "EA_fam_ucGetAcqrSignInfo";
        goto LABEL_79;
      }
      v15 = (int)(v6 + 1);
      if ( EI_fam_ucGetSeqInfo(v6 + 1, &v62, (char *)&v57 + 3) )
      {
        v11 = 411;
        v12 = "[File] : %s; [Line] : %d; [Func] : %s; error.";
        v13 = "epay/security/fam/jni/common/signfilefunApi.c";
        v14 = "EA_fam_ucGetAcqrSignInfo";
        goto LABEL_79;
      }
      v16 = v62 + 1 + BYTE3(v57);
      if ( v16 != v7 )
      {
        v11 = 417;
        v12 = "[File] : %s; [Line] : %d; [Func] : %s; error.";
        v13 = "epay/security/fam/jni/common/signfilefunApi.c";
        v14 = "EA_fam_ucGetAcqrSignInfo";
        goto LABEL_79;
      }
      if ( *(_BYTE *)(v15 + BYTE3(v57)) != 48 )
      {
        v11 = 427;
        v12 = "[File] : %s; [Line] : %d; [Func] : %s; error.";
        v13 = "epay/security/fam/jni/common/signfilefunApi.c";
        v14 = "EA_fam_ucGetAcqrSignInfo";
        goto LABEL_79;
      }
      v17 = v15 + BYTE3(v57) + 1;
      v10 = EI_fam_ucGetSeqInfo(v17, &v62, (char *)&v57 + 3);
      if ( v10 == 1 )
      {
        v18 = 433;
        v19 = "[File] : %s; [Line] : %d; [Func] : %s; error.";
        v20 = "epay/security/fam/jni/common/signfilefunApi.c";
        v21 = "EA_fam_ucGetAcqrSignInfo";
        goto LABEL_53;
      }
      v22 = v62;
      v23 = (_BYTE *)(v17 + BYTE3(v57));
      *(_DWORD *)(v8 + 4) = v17 + BYTE3(v57) - (_DWORD)v6;
      *(_DWORD *)v8 = v22;
      if ( *v23 != 2 )
      {
        v11 = 445;
        v12 = "[File] : %s; [Line] : %d; [Func] : %s; error.";
        v13 = "epay/security/fam/jni/common/signfilefunApi.c";
        v14 = "EA_fam_ucGetAcqrSignInfo";
        goto LABEL_79;
      }
      v24 = (int)(v23 + 1);
      v10 = EI_fam_ucGetSeqInfo(v24, &v62, (char *)&v57 + 3);
      if ( v10 == 1 )
      {
        v18 = 451;
        v19 = "[File] : %s; [Line] : %d; [Func] : %s; error.";
        v20 = "epay/security/fam/jni/common/signfilefunApi.c";
        v21 = "EA_fam_ucGetAcqrSignInfo";
        goto LABEL_53;
      }
      v25 = v24 + BYTE3(v57);
      if ( *(_BYTE *)(v24 + BYTE3(v57)) != 1 )
      {
        v11 = 460;
        v12 = "[File] : %s; [Line] : %d; [Func] : %s; error.";
        v13 = "epay/security/fam/jni/common/signfilefunApi.c";
        v14 = "EA_fam_ucGetAcqrSignInfo";
        goto LABEL_79;
      }
      v26 = v62;
      v27 = (unsigned int)&v6[v16];
      v10 = 1;
      *(_BYTE *)(v4 + 32) = 1;
      if ( v25 + v26 >= v27 )
      {
        v18 = 469;
        v19 = "[File] : %s; [Line] : %d; [Func] : %s; error.";
        v20 = "epay/security/fam/jni/common/signfilefunApi.c";
        v21 = "EA_fam_ucGetAcqrSignInfo";
        goto LABEL_53;
      }
      if ( *(_BYTE *)(v25 + v26) != 19 )
      {
        v18 = 477;
        v19 = "[File] : %s; [Line] : %d; [Func] : %s; error.";
        v20 = "epay/security/fam/jni/common/signfilefunApi.c";
        v21 = "EA_fam_ucGetAcqrSignInfo";
        goto LABEL_53;
      }
      v28 = v25 + v26 + 1;
      v29 = EI_fam_ucGetSeqInfo(v28, &v62, (char *)&v57 + 3);
      if ( v29 == 1 )
      {
        v30 = 483;
        v31 = "[File] : %s; [Line] : %d; [Func] : %s; error.";
        v32 = "epay/security/fam/jni/common/signfilefunApi.c";
        v33 = "EA_fam_ucGetAcqrSignInfo";
      }
      else
      {
        v34 = (const void *)(v28 + BYTE3(v57));
        memcpy((void *)(v4 + 33), v34, 0xCu);
        v35 = (int)v34 + v62;
        if ( (unsigned int)v34 + v62 >= v27 )
        {
          v18 = 493;
          v19 = "[File] : %s; [Line] : %d; [Func] : %s; error.";
          v20 = "epay/security/fam/jni/common/signfilefunApi.c";
          v21 = "EA_fam_ucGetAcqrSignInfo";
          goto LABEL_53;
        }
        if ( *((_BYTE *)v34 + v62) != 6 )
        {
          v18 = 501;
          v19 = "[File] : %s; [Line] : %d; [Func] : %s; error.";
          v20 = "epay/security/fam/jni/common/signfilefunApi.c";
          v21 = "EA_fam_ucGetAcqrSignInfo";
          goto LABEL_53;
        }
        v36 = v35 + 1;
        v29 = EI_fam_ucGetSeqInfo(v35 + 1, &v62, (char *)&v57 + 3);
        if ( v29 != 1 )
        {
          v37 = (char *)(v36 + BYTE3(v57));
          if ( !memcmp(v37, &unk_878F, 9u) )
          {
            v38 = v62;
            *(_BYTE *)(v4 + 45) = 1;
            v39 = (int)&v37[v38];
            if ( (unsigned int)&v37[v38] < v27 )
            {
              if ( v37[v38] == 19 )
              {
                v40 = v39 + 1;
                if ( EI_fam_ucGetSeqInfo(v39 + 1, &v62, (char *)&v57 + 3) == 1 )
                {
                  v11 = 540;
                  v12 = "[File] : %s; [Line] : %d; [Func] : %s; error.";
                  v13 = "epay/security/fam/jni/common/signfilefunApi.c";
                  v14 = "EA_fam_ucGetAcqrSignInfo";
                  goto LABEL_79;
                }
                v41 = (const void *)(v40 + BYTE3(v57));
                memcpy((void *)(v4 + 46), v41, 0x10u);
                if ( (unsigned int)v41 + v62 >= v27 )
                {
                  v11 = 551;
                  v12 = "[File] : %s; [Line] : %d; [Func] : %s; error.";
                  v13 = "epay/security/fam/jni/common/signfilefunApi.c";
                  v14 = "EA_fam_ucGetAcqrSignInfo";
                  goto LABEL_79;
                }
                if ( *((_BYTE *)v41 + v62) != 2 )
                {
                  v11 = 559;
                  v12 = "[File] : %s; [Line] : %d; [Func] : %s; error.";
                  v13 = "epay/security/fam/jni/common/signfilefunApi.c";
                  v14 = "EA_fam_ucGetAcqrSignInfo";
                  goto LABEL_79;
                }
                v42 = (int)v41 + v62 + 1;
                v10 = EI_fam_ucGetSeqInfo(v42, &v62, (char *)&v57 + 3);
                if ( v10 != 1 )
                {
                  v43 = (const void *)(v42 + BYTE3(v57));
                  memcpy((void *)(v4 + 62), v43, 0x20u);
                  if ( (unsigned int)v43 + v62 < v27 )
                  {
                    if ( *((_BYTE *)v43 + v62) == 163 )
                    {
                      v44 = (int)v43 + v62 + 1;
                      if ( EI_fam_ucGetSeqInfo(v44, &v62, (char *)&v57 + 3) )
                      {
                        v11 = 590;
                        v12 = "[File] : %s; [Line] : %d; [Func] : %s; error.";
                        v13 = "epay/security/fam/jni/common/signfilefunApi.c";
                        v14 = "EA_fam_ucGetAcqrSignInfo";
                      }
                      else
                      {
                        v45 = v44 + BYTE3(v57);
                        if ( *(_BYTE *)(v44 + BYTE3(v57)) == 48 )
                        {
                          v46 = v45 + 1;
                          if ( EI_fam_ucGetSeqInfo(v45 + 1, &v62, (char *)&v57 + 3) )
                          {
                            v11 = 603;
                            v12 = "[File] : %s; [Line] : %d; [Func] : %s; error.";
                            v13 = "epay/security/fam/jni/common/signfilefunApi.c";
                            v14 = "EA_fam_ucGetAcqrSignInfo";
                          }
                          else
                          {
                            v47 = v46 + BYTE3(v57);
                            v48 = v47 + v62;
                            if ( v47 + v62 < v27 )
                            {
                              if ( *(_BYTE *)(v47 + v62) == 2 )
                              {
                                v49 = v48 + 1;
                                if ( EI_fam_ucGetSeqInfo(v48 + 1, &v62, (char *)&v57 + 3) )
                                {
                                  v11 = 626;
                                  v12 = "[File] : %s; [Line] : %d; [Func] : %s; error.";
                                  v13 = "epay/security/fam/jni/common/signfilefunApi.c";
                                  v14 = "EA_fam_ucGetAcqrSignInfo";
                                }
                                else
                                {
                                  v50 = v62;
                                  v51 = v49 + BYTE3(v57);
                                  *(_DWORD *)(v8 + 12) = v51 - (_DWORD)v6;
                                  *(_DWORD *)(v8 + 8) = v50;
                                  if ( v51 + v50 < v27 )
                                  {
                                    if ( *(_BYTE *)(v51 + v50) == 3 )
                                    {
                                      v52 = v51 + v50 + 1;
                                      if ( EI_fam_ucGetSeqInfo(v52, &v62, (char *)&v57 + 3) )
                                      {
                                        v11 = 651;
                                        v12 = "[File] : %s; [Line] : %d; [Func] : %s; error.";
                                        v13 = "epay/security/fam/jni/common/signfilefunApi.c";
                                        v14 = "EA_fam_ucGetAcqrSignInfo";
                                      }
                                      else
                                      {
                                        v54 = v52 + BYTE3(v57) + 1;
                                        v55 = v54 + v62-- - 1;
                                        v53 = v62;
                                        *(_DWORD *)(v8 + 20) = v54 - (_DWORD)v6;
                                        *(_DWORD *)(v8 + 16) = v53;
                                        if ( v27 == v55 )
                                          return 0;
                                        v11 = 665;
                                        v12 = "[File] : %s; [Line] : %d; [Func] : %s; error.";
                                        v13 = "epay/security/fam/jni/common/signfilefunApi.c";
                                        v14 = "EA_fam_ucGetAcqrSignInfo";
                                      }
                                    }
                                    else
                                    {
                                      v11 = 645;
                                      v12 = "[File] : %s; [Line] : %d; [Func] : %s; error.";
                                      v13 = "epay/security/fam/jni/common/signfilefunApi.c";
                                      v14 = "EA_fam_ucGetAcqrSignInfo";
                                    }
                                  }
                                  else
                                  {
                                    v11 = 637;
                                    v12 = "[File] : %s; [Line] : %d; [Func] : %s; error.";
                                    v13 = "epay/security/fam/jni/common/signfilefunApi.c";
                                    v14 = "EA_fam_ucGetAcqrSignInfo";
                                  }
                                }
                              }
                              else
                              {
                                v11 = 620;
                                v12 = "[File] : %s; [Line] : %d; [Func] : %s; error.";
                                v13 = "epay/security/fam/jni/common/signfilefunApi.c";
                                v14 = "EA_fam_ucGetAcqrSignInfo";
                              }
                            }
                            else
                            {
                              v11 = 612;
                              v12 = "[File] : %s; [Line] : %d; [Func] : %s; error.";
                              v13 = "epay/security/fam/jni/common/signfilefunApi.c";
                              v14 = "EA_fam_ucGetAcqrSignInfo";
                            }
                          }
                        }
                        else
                        {
                          v11 = 597;
                          v12 = "[File] : %s; [Line] : %d; [Func] : %s; ---error.";
                          v13 = "epay/security/fam/jni/common/signfilefunApi.c";
                          v14 = "EA_fam_ucGetAcqrSignInfo";
                        }
                      }
                    }
                    else
                    {
                      v11 = 584;
                      v12 = "[File] : %s; [Line] : %d; [Func] : %s; error.";
                      v13 = "epay/security/fam/jni/common/signfilefunApi.c";
                      v14 = "EA_fam_ucGetAcqrSignInfo";
                    }
                  }
                  else
                  {
                    v11 = 576;
                    v12 = "[File] : %s; [Line] : %d; [Func] : %s; error.";
                    v13 = "epay/security/fam/jni/common/signfilefunApi.c";
                    v14 = "EA_fam_ucGetAcqrSignInfo";
                  }
LABEL_79:
                  printf(v12, v13, v11, v14, v61);
                  return 1;
                }
                v18 = 565;
                v19 = "[File] : %s; [Line] : %d; [Func] : %s; error.";
                v20 = "epay/security/fam/jni/common/signfilefunApi.c";
                v21 = "EA_fam_ucGetAcqrSignInfo";
              }
              else
              {
                v18 = 534;
                v19 = "[File] : %s; [Line] : %d; [Func] : %s; error.";
                v20 = "epay/security/fam/jni/common/signfilefunApi.c";
                v21 = "EA_fam_ucGetAcqrSignInfo";
              }
            }
            else
            {
              v18 = 526;
              v19 = "[File] : %s; [Line] : %d; [Func] : %s; error.";
              v20 = "epay/security/fam/jni/common/signfilefunApi.c";
              v21 = "EA_fam_ucGetAcqrSignInfo";
            }
          }
          else
          {
            v18 = 519;
            v19 = "[File] : %s; [Line] : %d; [Func] : %s; error.";
            v20 = "epay/security/fam/jni/common/signfilefunApi.c";
            v21 = "EA_fam_ucGetAcqrSignInfo";
          }
LABEL_53:
          printf(v19, v20, v18, v21, v60);
          return v10;
        }
        v30 = 507;
        v31 = "[File] : %s; [Line] : %d; [Func] : %s; error.";
        v32 = "epay/security/fam/jni/common/signfilefunApi.c";
        v33 = "EA_fam_ucGetAcqrSignInfo";
      }
      printf(v31, v32, v30, v33, v59);
      return v29;
    }
  }
  v10 = 2;
  printf(
    "[File] : %s; [Line] : %d; [Func] : %s; err.",
    "epay/security/fam/jni/common/signfilefunApi.c",
    391,
    "EA_fam_ucGetAcqrSignInfo",
    v58);
  return v10;
}

int EA_fam_ucGetCrtInfo(int a1, int a2, int a3)
{
  int v3; // r8@1
  int v4; // r3@1
  int v5; // r10@1
  int v6; // r4@1
  int result; // r0@2
  int v8; // r7@3
  int v9; // r9@5
  _BYTE *v10; // r10@9
  unsigned int v11; // r3@11
  unsigned int v12; // r9@11
  unsigned int v13; // r7@11
  _BYTE *v14; // r7@23
  signed __int64 v15; // r2@25
  size_t v16; // r1@25
  int v17; // r7@25
  int i; // r5@25
  __int64 v19; // ST10_8@26
  int v20; // r3@28
  _BYTE *v21; // r6@32
  int v22; // r3@34
  size_t v23; // r0@34
  _BYTE *v24; // r5@35
  _BYTE *v25; // r5@36
  size_t v26; // r3@37
  int v27; // r2@37
  unsigned int v28; // r3@37
  int v29; // r5@41
  int v30; // r3@43
  int v31; // r5@43
  int v32; // r2@43
  int v33; // r5@47
  int v34; // r5@49
  int v35; // r3@49
  int v36; // r2@49
  char v37; // cf@49
  int v38; // r5@54
  int v39; // r3@56
  int v40; // r2@56
  _BYTE *v41; // r5@60
  int v42; // r3@60
  int v43; // r5@62
  size_t v44; // r6@62
  int v45; // r3@66
  int v46; // r5@71
  size_t v47; // r0@73
  int v48; // r5@73
  int v49; // r2@73
  _BYTE *v50; // r5@73
  _BYTE *v51; // r5@78
  int v52; // r3@80
  size_t v53; // r1@80
  _BYTE *v54; // r6@81
  _BYTE *v55; // r6@82
  size_t v56; // r5@83
  int v57; // r3@83
  unsigned int v58; // r5@83
  _BYTE *v59; // r5@86
  size_t v60; // r3@90
  int v61; // r2@90
  unsigned __int8 v62; // [sp+1Bh] [bp-3Dh]@3
  size_t v63; // [sp+1Ch] [bp-3Ch]@3
  char v64; // [sp+20h] [bp-38h]@28
  int v65; // [sp+2Ch] [bp-2Ch]@1

  v3 = a1;
  v4 = *(_BYTE *)a1;
  v5 = a2;
  v6 = a3;
  v65 = _stack_chk_guard;
  if ( v4 != 48 )
  {
    printf(
      "[File] : %s; [Line] : %d; [Func] : %s; err.",
      "epay/security/fam/jni/common/signfilefunApi.c",
      720,
      "EA_fam_ucGetCrtInfo");
    result = 32;
    goto LABEL_94;
  }
  v8 = a1 + 1;
  if ( EI_fam_ucGetSeqInfo((_BYTE *)(a1 + 1), (int *)&v63, (char *)&v62, 48) == 1 )
  {
    printf(
      "[File] : %s; [Line] : %d; [Func] : %s; err.",
      "epay/security/fam/jni/common/signfilefunApi.c",
      728,
      "EA_fam_ucGetCrtInfo");
    result = 33;
    goto LABEL_94;
  }
  printf(
    "[File] : %s; [Line] : %d; [Func] : %s; ---------1 + ucOffset + uiLen = %d, ---------uiCrtLen = %d-------------- \n",
    "epay/security/fam/jni/common/signfilefunApi.c",
    731,
    "EA_fam_ucGetCrtInfo",
    v63 + 1 + v62,
    v5);
  v9 = v63 + 1 + v62;
  if ( v9 != v5 )
  {
    printf(
      "[File] : %s; [Line] : %d; [Func] : %s; err.",
      "epay/security/fam/jni/common/signfilefunApi.c",
      735,
      "EA_fam_ucGetCrtInfo");
    result = 34;
    goto LABEL_94;
  }
  if ( *(_BYTE *)(v8 + v62) != 48 )
  {
    printf(
      "[File] : %s; [Line] : %d; [Func] : %s; err.",
      "epay/security/fam/jni/common/signfilefunApi.c",
      747,
      "EA_fam_ucGetCrtInfo");
    result = 35;
    goto LABEL_94;
  }
  v10 = (_BYTE *)(v8 + v62 + 1);
  if ( EI_fam_ucGetSeqInfo(v10, (int *)&v63, (char *)&v62, v62) == 1 )
  {
    printf(
      "[File] : %s; [Line] : %d; [Func] : %s; err.",
      "epay/security/fam/jni/common/signfilefunApi.c",
      755,
      "EA_fam_ucGetCrtInfo");
    result = 36;
    goto LABEL_94;
  }
  v11 = v62;
  v12 = v9 + v3;
  v13 = (unsigned int)&v10[v62];
  if ( v13 >= v12 )
  {
    printf(
      "[File] : %s; [Line] : %d; [Func] : %s; err.",
      "epay/security/fam/jni/common/signfilefunApi.c",
      763,
      "EA_fam_ucGetCrtInfo");
    result = 37;
    goto LABEL_94;
  }
  if ( v10[v62] == 160 )
  {
    if ( memcmp((const void *)(v13 + 1), &EM_fam_aucVerData, 3u) )
    {
      printf(
        "[File] : %s; [Line] : %d; [Func] : %s; err.",
        "epay/security/fam/jni/common/signfilefunApi.c",
        774,
        "EA_fam_ucGetCrtInfo");
      result = 38;
      goto LABEL_94;
    }
    *(_DWORD *)v6 = 3;
    *(_DWORD *)(v6 + 4) = v13 + 2 - v3;
    v11 = *(_BYTE *)(v13 + 4);
    if ( v11 > 2 )
    {
      printf(
        "[File] : %s; [Line] : %d; [Func] : %s; err.",
        "epay/security/fam/jni/common/signfilefunApi.c",
        788,
        "EA_fam_ucGetCrtInfo");
      result = 39;
      goto LABEL_94;
    }
    v13 += 5;
    *(_DWORD *)(v6 + 8) = v11;
    if ( v13 >= v12 )
    {
      printf(
        "[File] : %s; [Line] : %d; [Func] : %s; err.",
        "epay/security/fam/jni/common/signfilefunApi.c",
        795,
        "EA_fam_ucGetCrtInfo");
      result = 40;
      goto LABEL_94;
    }
  }
  else
  {
    *(_DWORD *)(v6 + 4) = 0;
    *(_DWORD *)v6 = 0;
    *(_DWORD *)(v6 + 8) = 0;
  }
  if ( *(_BYTE *)v13 != 2 )
  {
    printf(
      "[File] : %s; [Line] : %d; [Func] : %s; err.",
      "epay/security/fam/jni/common/signfilefunApi.c",
      810,
      "EA_fam_ucGetCrtInfo");
    result = 41;
    goto LABEL_94;
  }
  v14 = (_BYTE *)(v13 + 1);
  if ( EI_fam_ucGetSeqInfo(v14, (int *)&v63, (char *)&v62, v11) == 1 )
  {
    printf(
      "[File] : %s; [Line] : %d; [Func] : %s; err.",
      "epay/security/fam/jni/common/signfilefunApi.c",
      817,
      "EA_fam_ucGetCrtInfo");
    result = 48;
    goto LABEL_94;
  }
  v15 = 0LL;
  v16 = v63;
  v17 = (int)&v14[v62];
  *(_DWORD *)(v6 + 16) = v17 - v3;
  *(_DWORD *)(v6 + 12) = v16;
  for ( i = 0; i != v16; ++i )
  {
    LODWORD(v19) = (_DWORD)v15 << 8;
    HIDWORD(v19) = v15 >> 24;
    v15 = *(_BYTE *)(v17 + i) + v19;
  }
  sprintf(&v64, "%lld", v15);
  v63 = strlen(&v64);
  memset((void *)(v6 + 20), 48, 0xCu);
  memcpy((void *)(v6 - v63 + 31), &v64, v63 + 1);
  if ( v17 + i >= v12 )
  {
    printf(
      "[File] : %s; [Line] : %d; [Func] : %s; err.",
      "epay/security/fam/jni/common/signfilefunApi.c",
      842,
      "EA_fam_ucGetCrtInfo");
    result = 49;
    goto LABEL_94;
  }
  if ( *(_BYTE *)(v17 + i) != 48 )
  {
    printf(
      "[File] : %s; [Line] : %d; [Func] : %s; err.",
      "epay/security/fam/jni/common/signfilefunApi.c",
      850,
      "EA_fam_ucGetCrtInfo");
LABEL_92:
    result = 50;
    goto LABEL_94;
  }
  v21 = (_BYTE *)(v17 + i + 1);
  if ( EI_fam_ucGetSeqInfo(v21, (int *)&v63, (char *)&v62, v20) == 1 )
  {
    printf(
      "[File] : %s; [Line] : %d; [Func] : %s; err.",
      "epay/security/fam/jni/common/signfilefunApi.c",
      857,
      "EA_fam_ucGetCrtInfo");
LABEL_93:
    result = 51;
    goto LABEL_94;
  }
  v22 = v62;
  v23 = v63;
  *(_DWORD *)(v6 + 36) = &v21[v62] - v3;
  *(_DWORD *)(v6 + 32) = v23;
  if ( v21[v22] != 6 )
    goto LABEL_92;
  v24 = &v21[v22 + 1];
  if ( EI_fam_ucGetSeqInfo(v24, (int *)&v63, (char *)&v62, v22) == 1 )
    goto LABEL_93;
  v25 = &v24[v62];
  if ( memcmp(v25, &unk_878F, 9u) )
    goto LABEL_93;
  v26 = v63;
  *(_BYTE *)(v6 + 41) = 0;
  v27 = v26 + 2;
  *(_BYTE *)(v6 + 40) = 1;
  v28 = (unsigned int)&v25[v26 + 2];
  if ( v28 >= v12 )
  {
    printf(
      "[File] : %s; [Line] : %d; [Func] : %s; err.",
      "epay/security/fam/jni/common/signfilefunApi.c",
      892,
      "EA_fam_ucGetCrtInfo");
    result = 52;
    goto LABEL_94;
  }
  if ( v25[v27] != 48 )
  {
    printf(
      "[File] : %s; [Line] : %d; [Func] : %s; err.",
      "epay/security/fam/jni/common/signfilefunApi.c",
      900,
      "EA_fam_ucGetCrtInfo");
    result = 53;
    goto LABEL_94;
  }
  v29 = v28 + 1;
  if ( EI_fam_ucGetSeqInfo((_BYTE *)(v28 + 1), (int *)&v63, (char *)&v62, v28) == 1 )
  {
    printf(
      "[File] : %s; [Line] : %d; [Func] : %s; err.",
      "epay/security/fam/jni/common/signfilefunApi.c",
      907,
      "EA_fam_ucGetCrtInfo");
    result = 54;
    goto LABEL_94;
  }
  v30 = v63;
  v31 = v29 + v62;
  *(_DWORD *)(v6 + 48) = v31 - v3;
  v32 = v31 + v30;
  *(_DWORD *)(v6 + 44) = v30;
  if ( v31 + v30 >= v12 )
  {
    printf(
      "[File] : %s; [Line] : %d; [Func] : %s; err.",
      "epay/security/fam/jni/common/signfilefunApi.c",
      916,
      "EA_fam_ucGetCrtInfo");
    result = 55;
    goto LABEL_94;
  }
  if ( *(_BYTE *)(v31 + v30) != 48 )
  {
    printf(
      "[File] : %s; [Line] : %d; [Func] : %s; err.",
      "epay/security/fam/jni/common/signfilefunApi.c",
      924,
      "EA_fam_ucGetCrtInfo");
    result = 56;
    goto LABEL_94;
  }
  v33 = v32 + 1;
  if ( EI_fam_ucGetSeqInfo((_BYTE *)(v32 + 1), (int *)&v63, (char *)&v62, v30) == 1 )
  {
    printf(
      "[File] : %s; [Line] : %d; [Func] : %s; err.",
      "epay/security/fam/jni/common/signfilefunApi.c",
      931,
      "EA_fam_ucGetCrtInfo");
    result = 57;
    goto LABEL_94;
  }
  v34 = v33 + v62;
  *(_DWORD *)(v6 + 56) = v34 - v3;
  v35 = v63;
  v36 = v34 + v63;
  v37 = v34 + v63 >= v12;
  *(_DWORD *)(v6 + 52) = v63;
  if ( v37 )
  {
    printf(
      "[File] : %s; [Line] : %d; [Func] : %s; err.",
      "epay/security/fam/jni/common/signfilefunApi.c",
      941,
      "EA_fam_ucGetCrtInfo");
    result = 64;
    goto LABEL_94;
  }
  if ( *(_BYTE *)(v34 + v35) != 48 )
  {
    printf(
      "[File] : %s; [Line] : %d; [Func] : %s; err.",
      "epay/security/fam/jni/common/signfilefunApi.c",
      949,
      "EA_fam_ucGetCrtInfo");
    result = 65;
    goto LABEL_94;
  }
  v38 = v36 + 1;
  if ( EI_fam_ucGetSeqInfo((_BYTE *)(v36 + 1), (int *)&v63, (char *)&v62, v35) == 1 )
  {
    printf(
      "[File] : %s; [Line] : %d; [Func] : %s; err.",
      "epay/security/fam/jni/common/signfilefunApi.c",
      956,
      "EA_fam_ucGetCrtInfo");
    result = 66;
    goto LABEL_94;
  }
  v39 = v63;
  v40 = v38 + v62;
  *(_DWORD *)(v6 + 80) = v40 - v3;
  *(_DWORD *)(v6 + 76) = v39;
  if ( v40 + v39 >= v12 )
  {
    printf(
      "[File] : %s; [Line] : %d; [Func] : %s; err.",
      "epay/security/fam/jni/common/signfilefunApi.c",
      967,
      "EA_fam_ucGetCrtInfo");
    result = 67;
    goto LABEL_94;
  }
  if ( *(_BYTE *)(v40 + v39) != 48 )
  {
    printf(
      "[File] : %s; [Line] : %d; [Func] : %s; err.",
      "epay/security/fam/jni/common/signfilefunApi.c",
      975,
      "EA_fam_ucGetCrtInfo");
    result = 68;
    goto LABEL_94;
  }
  v41 = (_BYTE *)(v40 + v39 + 1);
  if ( EI_fam_ucGetSeqInfo(v41, (int *)&v63, (char *)&v62, v39) == 1 )
  {
    printf(
      "[File] : %s; [Line] : %d; [Func] : %s; err.",
      "epay/security/fam/jni/common/signfilefunApi.c",
      982,
      "EA_fam_ucGetCrtInfo");
    result = 69;
    goto LABEL_94;
  }
  v43 = (int)&v41[v62];
  *(_DWORD *)(v6 + 88) = v43 - v3;
  v44 = v63;
  *(_DWORD *)(v6 + 84) = v63;
  if ( *(_BYTE *)(v43 + 2) != 6 )
    goto LABEL_92;
  if ( EI_fam_ucGetSeqInfo((_BYTE *)(v43 + 3), (int *)&v63, (char *)&v62, v42) == 1 )
    goto LABEL_93;
  if ( !memcmp((const void *)(v43 + 3 + v62), &unk_8841, 9u) )
    *(_DWORD *)(v6 + 92) = 0;
  v45 = v43 + v44;
  if ( v43 + v44 >= v12 )
  {
    printf(
      "[File] : %s; [Line] : %d; [Func] : %s; err.",
      "epay/security/fam/jni/common/signfilefunApi.c",
      1012,
      "EA_fam_ucGetCrtInfo");
    result = 70;
    goto LABEL_94;
  }
  if ( *(_DWORD *)(v6 + 8) )
  {
    if ( *(_BYTE *)(v43 + v44) != 163 )
    {
      printf(
        "[File] : %s; [Line] : %d; [Func] : %s; err.",
        "epay/security/fam/jni/common/signfilefunApi.c",
        1022,
        "EA_fam_ucGetCrtInfo");
      result = 71;
      goto LABEL_94;
    }
    v46 = v45 + 1;
    if ( EI_fam_ucGetSeqInfo((_BYTE *)(v45 + 1), (int *)&v63, (char *)&v62, v45) == 1 )
    {
      printf(
        "[File] : %s; [Line] : %d; [Func] : %s; err.",
        "epay/security/fam/jni/common/signfilefunApi.c",
        1029,
        "EA_fam_ucGetCrtInfo");
      result = 72;
      goto LABEL_94;
    }
    v47 = v63;
    v48 = v46 + v62;
    v49 = v48 - v3;
    v50 = (_BYTE *)(v48 + v63);
    *(_DWORD *)(v6 + 116) = v49;
    *(_DWORD *)(v6 + 112) = v47;
    if ( (unsigned int)v50 >= v12 )
    {
      printf(
        "[File] : %s; [Line] : %d; [Func] : %s; err.",
        "epay/security/fam/jni/common/signfilefunApi.c",
        1038,
        "EA_fam_ucGetCrtInfo");
      result = 73;
      goto LABEL_94;
    }
  }
  else
  {
    v50 = (_BYTE *)(v43 + v44);
    *(_DWORD *)(v6 + 116) = 0;
    *(_DWORD *)(v6 + 112) = 0;
  }
  if ( *v50 != 48 )
  {
    printf(
      "[File] : %s; [Line] : %d; [Func] : %s; err.",
      "epay/security/fam/jni/common/signfilefunApi.c",
      1051,
      "EA_fam_ucGetCrtInfo");
    result = 80;
    goto LABEL_94;
  }
  v51 = v50 + 1;
  if ( EI_fam_ucGetSeqInfo(v51, (int *)&v63, (char *)&v62, v45) == 1 )
  {
    printf(
      "[File] : %s; [Line] : %d; [Func] : %s; err.",
      "epay/security/fam/jni/common/signfilefunApi.c",
      1058,
      "EA_fam_ucGetCrtInfo");
    result = 81;
    goto LABEL_94;
  }
  v52 = v62;
  v53 = v63;
  *(_DWORD *)(v6 + 184) = &v51[v62] - v3;
  *(_DWORD *)(v6 + 180) = v53;
  if ( v51[v52] != 6 )
    goto LABEL_92;
  v54 = &v51[v52 + 1];
  if ( EI_fam_ucGetSeqInfo(v54, (int *)&v63, (char *)&v62, v52) == 1 )
    goto LABEL_93;
  v55 = &v54[v62];
  if ( memcmp(v55, &unk_878F, 9u) )
    goto LABEL_93;
  v56 = v63;
  *(_BYTE *)(v6 + 188) = 1;
  v57 = v56 + 2;
  *(_BYTE *)(v6 + 189) = 0;
  v58 = (unsigned int)&v55[v56 + 2];
  result = 82;
  if ( v58 < v12 )
  {
    if ( v55[v57] == 3 )
    {
      v59 = (_BYTE *)(v58 + 1);
      if ( EI_fam_ucGetSeqInfo(v59, (int *)&v63, (char *)&v62, v57) == 1 )
      {
        printf(
          "[File] : %s; [Line] : %d; [Func] : %s; err.",
          "epay/security/fam/jni/common/signfilefunApi.c",
          1106,
          "EA_fam_ucGetCrtInfo");
        result = 84;
      }
      else if ( v59[v62] )
      {
        printf(
          "[File] : %s; [Line] : %d; [Func] : %s; err.",
          "epay/security/fam/jni/common/signfilefunApi.c",
          1114,
          "EA_fam_ucGetCrtInfo");
        result = 85;
      }
      else
      {
        v60 = v63;
        v61 = (int)&v59[v62 + 1];
        *(_DWORD *)(v6 + 196) = v61 - v3;
        v63 = v60 - 1;
        *(_DWORD *)(v6 + 192) = v60 - 1;
        result = 0;
        if ( v12 != v61 + v60 - 1 )
        {
          printf(
            "[File] : %s; [Line] : %d; [Func] : %s; err.",
            "epay/security/fam/jni/common/signfilefunApi.c",
            1126,
            "EA_fam_ucGetCrtInfo");
          result = 86;
        }
      }
    }
    else
    {
      printf(
        "[File] : %s; [Line] : %d; [Func] : %s; err.",
        "epay/security/fam/jni/common/signfilefunApi.c",
        1099,
        "EA_fam_ucGetCrtInfo");
      result = 83;
    }
  }
LABEL_94:
  if ( v65 != _stack_chk_guard )
    _stack_chk_fail(result);
  return result;
}

signed int EA_ucGetCertSubOffset(unsigned int a1, int a2, _DWORD *a3, int *a4)
{
  int *v4; // r9@1
  unsigned int v5; // r6@1
  int v6; // r4@1
  _DWORD *v7; // r5@1
  int v8; // r7@2
  signed int result; // r0@2
  int v10; // r8@3
  _BYTE *v11; // r6@5
  unsigned int v12; // r6@6
  int v13; // r3@7
  unsigned int v14; // [sp+0h] [bp-28h]@1
  int v15; // [sp+4h] [bp-24h]@1
  _DWORD *v16; // [sp+8h] [bp-20h]@1

  v14 = a1;
  v15 = a2;
  v16 = a3;
  v4 = a4;
  v5 = a1;
  v6 = a2;
  v7 = a3;
  if ( *(_BYTE *)a2 != 48 )
    goto LABEL_11;
  v8 = a2 + 1;
  result = EI_fam_ucGetSeqInfo((_BYTE *)(a2 + 1), &v15, (char *)&v14 + 3, 48);
  if ( result == 1 )
    return result;
  v10 = v15 + 1 + BYTE3(v14);
  if ( v10 != v5 || *(_BYTE *)(v8 + BYTE3(v14)) != 48 )
    goto LABEL_11;
  v11 = (_BYTE *)(v8 + BYTE3(v14) + 1);
  result = EI_fam_ucGetSeqInfo(v11, &v15, (char *)&v14 + 3, BYTE3(v14));
  if ( result == 1 )
    return result;
  v12 = (unsigned int)&v11[BYTE3(v14)];
  if ( v12 >= v10 + v6 )
  {
LABEL_11:
    result = 1;
  }
  else
  {
    v13 = v15;
    result = 0;
    *v7 = v12 - v6;
    *v4 = v13;
  }
  return result;
}