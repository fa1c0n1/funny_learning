#ifndef _COMMON_H
#define _COMMON_H
#endif

typedef unsigned char uint8;
typedef unsigned short uint16;
typedef unsigned int uint32;
typedef int bool;

#define _BYTE        uint8
#define _WORD        uint16
#define _DWORD       uint32
#define __int32      int

#define __int8       char