#include "comm.h"

void doXor(char *pwd)
{
	for (int i = 0; pwd[i] != '\0'; i++)
		pwd[i] ^= 5;
}