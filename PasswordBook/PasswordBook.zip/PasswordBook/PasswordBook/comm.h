#ifndef _COMM_H
#define _COMM_H

extern void doXor(char *pwd);

#endif