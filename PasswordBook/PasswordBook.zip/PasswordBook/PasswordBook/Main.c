#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "data.h"
#include "ctrl.h"

void showMenu(void)
{
	printf("||============================================ ||\n");
	printf("||        Welcome to Use PasswordBook          ||\n");
	printf("||                Version 1.0                  ||\n");
	printf("||=============================================||\n");
	printf("    1. Show all records.\n");
	printf("    2. Add a new record.\n");
	printf("    3. Delete a record.\n");
	printf("    4. Update a record.\n");
	printf("    5. Search a record.\n");
	printf("    6. Generate a text PasswordBook file.\n");
	printf("    7. Exit.\n");
	printf("\nPlease make a choice: ");
}

int main(void)
{
	int nCount;
	PASSWORD *pwds = NULL;
	OPTION op;
	int isExit = 0;

	initPwdBook(&pwds, &nCount);
	
	while (!isExit) {
		showMenu();
		scanf_s("%d", &op);

		switch (op)
		{
		case OP_SHOWALL:
			system("cls");
			showAllInfo(&pwds, nCount);
			break;
		case OP_ADDITEM:
			insertInfo(&pwds, &nCount);
			break;
		case OP_DELITEM:
			deleteInfo(&pwds, &nCount);
			break;
		case OP_UPDATEITEM:
			updateInfo(&pwds, nCount);
			break;
		case OP_QUERY:
			searchInfo(&pwds, nCount);
			break;
		case OP_SAVE_TEXT:
			saveToTextFile(&pwds, nCount);
			break;
		case OP_QUIT:
			isExit = 1;
			freeResources(&pwds);
			printf("Exit...\n");
			break;
		default:
			getchar();
			system("cls");
			break;
		}
	}

	system("pause");
	return 0;
}

