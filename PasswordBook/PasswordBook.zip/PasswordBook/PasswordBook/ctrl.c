#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <memory.h>

#include "data.h"
#include "ctrl.h"

void initPwdBook(PASSWORD **pwds, int *nCount)
{
	FILE *pFile = NULL;
	*nCount = g_Num;

	if (fopen_s(&pFile, BIN_FILE, "rb") != 0) {
		return ;
	}

	fseek(pFile, 0, SEEK_END);
	int fileBytes = ftell(pFile);
	g_Num = *nCount = fileBytes / sizeof(PASSWORD);
	if (*nCount == 0) {
		fclose(pFile);
		return;
	}

	*pwds = (PASSWORD *)calloc(*nCount, sizeof(PASSWORD));
	rewind(pFile);
	for (int i = 0; i < *nCount; i++) {
		fread_s(*pwds + i, sizeof(PASSWORD), sizeof(PASSWORD), 1, pFile);
		doXor((*pwds + i)->password);
	}

	fclose(pFile);
}

void showAllInfo(PASSWORD **pwds, int nCount)
{
	if (nCount <= 0) {
		system("cls");
		printf("The PasswordBook is empty!\n");
		return;
	}

	printf("------ List of all info as below --------\n");
	for (int i = 0; i < nCount; i++) {
		printf("%d  |  %s  |  %s  |  %s  |  %s\n", i, (*pwds + i)->website, (*pwds + i)->userName, 
			(*pwds + i)->password, (*pwds + i)->intro);
	}
	printf("\n");
}

void insertInfo(PASSWORD **pwds, int *nCount)
{
	FILE *pFile = NULL;
	PASSWORD pwd;

	if (fopen_s(&pFile, BIN_FILE, "ab") != 0)
		return;

	getchar();
	printf("Please input website name: \n");
	gets_s(pwd.website, _countof(pwd.website));
	printf("Please input username: \n");
	gets_s(pwd.userName, _countof(pwd.userName));
	printf("Please input password: \n");
	gets_s(pwd.password, _countof(pwd.password));
	printf("Please input brief intro: \n");
	gets_s(pwd.intro, _countof(pwd.intro));

	doXor(pwd.password);
	fwrite(&pwd, sizeof(PASSWORD), 1, pFile);
	fclose(pFile);
	*nCount = ++g_Num;

	*pwds = (PASSWORD *)realloc(*pwds, g_Num * sizeof(PASSWORD));
	doXor(pwd.password);
	memcpy_s(*pwds + g_Num - 1, sizeof(PASSWORD), &pwd, sizeof(PASSWORD));

	printf("Add successfully.\n");
}

void deleteInfo(PASSWORD **pwds, int *nCount)
{
	int nIdx;
	FILE *pFile = NULL;

	if (*nCount <= 0) {
		system("cls");
		printf("The PasswordBook is empty!\n");
		return;
	}

	printf("Please input the index of record: ");
	scanf_s("%d", &nIdx);

	if (fopen_s(&pFile, BIN_FILE, "wb") != 0)
		return;

	memmove_s(*pwds + nIdx, (*nCount - nIdx) * sizeof(PASSWORD), 
		*pwds + nIdx + 1, (*nCount - nIdx - 1) * sizeof(PASSWORD));

	*nCount = --g_Num;
	for (int i = 0; i < *nCount; i++) {
		doXor((*pwds + i)->password);
	}

	fwrite(*pwds, sizeof(PASSWORD), *nCount, pFile);
	fclose(pFile);

	for (int i = 0; i < *nCount; i++) {
		doXor((*pwds + i)->password);
	}

	printf("Delete successfully.\n");
}

void updateInfo(PASSWORD **pwds, int nCount)
{
	int nIdx;
	FILE *pFile = NULL;
	PASSWORD pwd;

	if (nCount <= 0) {
		system("cls");
		printf("The PasswordBook is empty!\n");
		return;
	}

	printf("Please input the index of record: ");
	scanf_s("%d", &nIdx);

	if (fopen_s(&pFile, BIN_FILE, "r+b") != 0) {
		printf("Data file doesn't exist.\n");
		return;
	}

	getchar();
	printf("Please input website name: \n");
	gets_s(pwd.website, _countof(pwd.website));
	printf("Please input username: \n");
	gets_s(pwd.userName, _countof(pwd.userName));
	printf("Please input password: \n");
	gets_s(pwd.password, _countof(pwd.password));
	printf("Please input brief intro: \n");
	gets_s(pwd.intro, _countof(pwd.intro));

	doXor(pwd.password);
	fseek(pFile, nIdx * sizeof(PASSWORD), SEEK_SET);
	fwrite(&pwd, sizeof(PASSWORD), 1, pFile);
	fclose(pFile);

	doXor(pwd.password);
	memcpy_s(*pwds + nIdx, sizeof(PASSWORD), &pwd, sizeof(PASSWORD));

	printf("Update successfully!\n");
}

void searchInfo(PASSWORD **pwds, int nCount)
{
	char key[BUFLEN / 4];
	int nFindIdxs[100];
	int nFindCnt = 0;

	if (nCount <= 0) {
		system("cls");
		printf("The PasswordBook is empty!\n");
		return;
	}

	printf("Please input a keyword: ");
	scanf_s("%s", key, _countof(key));

	for (int i = 0; i < nCount; i++) {
		if (strstr((*pwds + i)->website, key)) {
			nFindIdxs[nFindCnt++] = i;
			continue;
		}

		if (strstr((*pwds + i)->userName, key)) {
			nFindIdxs[nFindCnt++] = i;
			continue;
		}

		if (strstr((*pwds + i)->password, key)) {
			nFindIdxs[nFindCnt++] = i;
			continue;
		}

		if (strstr((*pwds + i)->intro, key)) {
			nFindIdxs[nFindCnt++] = i;
			continue;
		}
	}

	if (nFindCnt == 0) {
		printf("Nothing found!\n");
		return;
	}

	printf("------ Search results as below --------\n");
	for (int i = 0; i < nFindCnt; i++) {
		int nIdx = nFindIdxs[i];
		printf("%d  |  %s  |  %s  |  %s  |  %s\n", nIdx, (*pwds + nIdx)->website, (*pwds + nIdx)->userName, 
			(*pwds + nIdx)->password, (*pwds + nIdx)->intro);
	}
	printf("\n");
}

void saveToTextFile(PASSWORD **pwds, int nCount)
{
	if (nCount <= 0) {
		system("cls");
		printf("The PasswordBook is empty!\n");
		return;
	}

	FILE *pFile = NULL;
	
	if (fopen_s(&pFile, TEXT_FILE, "w") != 0)
		return;
	
	fprintf_s(pFile, "Index  |  Website name  |  User name  |  Password  |  Intro\n");
	for (int i = 0; i < nCount; i++) {
		doXor((*pwds + i)->password);
		fprintf_s(pFile, "%d  |  %s  |  %s  |  %s  |  %s\n", i, (*pwds + i)->website, (*pwds + i)->userName,
			(*pwds + i)->password, (*pwds + i)->intro);
	}
	fclose(pFile);

	for (int i = 0; i < nCount; i++) {
		doXor((*pwds + i)->password);
	}

	printf("Text file password.txt has been generated successfully.\n");
}

void freeResources(PASSWORD **pwds)
{
	if (pwds == NULL || *pwds == NULL)
		return;

	free(*pwds);
	*pwds = NULL;
}
