#include "data.h"

int g_Num = 0;
