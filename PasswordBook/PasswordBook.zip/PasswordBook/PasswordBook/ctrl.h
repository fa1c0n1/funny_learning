#ifndef _CTRL_H
#define _CTRL_H

extern void initPwdBook(PASSWORD **pwds, int *nCount);
extern void showAllInfo(PASSWORD **pwds, int nCount);
extern void insertInfo(PASSWORD **pwds, int *nCount);
extern void deleteInfo(PASSWORD **pwds, int *nCount);
extern void updateInfo(PASSWORD **pwds, int nCount);
extern void searchInfo(PASSWORD **pwds, int nCount);
extern void saveToTextFile(PASSWORD **pwds, int nCount);
extern void freeResources(PASSWORD **pwds);

#endif