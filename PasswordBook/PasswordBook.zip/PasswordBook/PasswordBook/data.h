#ifndef _DATA_H
#define _DATA_H

#define TEXT_FILE    "pwdbook.txt"
#define BIN_FILE     "pwdbook.bin"

#define BUFLEN    512

extern int g_Num;

typedef enum {
	OP_SHOWALL = 1,
	OP_ADDITEM,
	OP_DELITEM,
	OP_UPDATEITEM,
	OP_QUERY,
	OP_SAVE_TEXT,
	OP_QUIT
} OPTION;

typedef struct {
	char website[BUFLEN / 4];    // Website Name
	char userName[BUFLEN / 4];   // User Name 
	char password[BUFLEN / 4];   // Password
	char intro[BUFLEN / 4];      // Brief infos
} PASSWORD;

#endif 